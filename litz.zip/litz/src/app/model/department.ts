export class Department {
id : String;
deptName : String;
}
