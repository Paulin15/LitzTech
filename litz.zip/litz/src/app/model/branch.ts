export class Branch {
id : String;
branchName : String;
}
