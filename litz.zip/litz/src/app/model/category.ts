export class Category {
id : String;
type : String;
}
