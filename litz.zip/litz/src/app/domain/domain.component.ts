import { Component, OnInit } from '@angular/core';
import { DepartmentService } from '../service/department.service';
import { CategoryService } from '../service/category.service';
import { Category } from '../model/category';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.css']
})
export class DomainComponent implements OnInit {

categories: Category[];

  constructor(
  private route: ActivatedRoute,
  private deptService: DepartmentService,
  private categoryService: CategoryService
) { }

  ngOnInit() {
	this.getCategories();

  }

getCategories(): void {
    this.categoryService.getCategories()
    .subscribe(categories => this.categories = categories);
  }
}
