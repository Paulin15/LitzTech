import { Injectable } from '@angular/core';
import { Category } from '../model/category';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient) { }

  getCategories() : Observable<Category[]>{
  	return this.http.get<Category[]>('./assets/category.json');
   
}
	
private handleError(error: Response) {
        console.error(error);

}

}

  