import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DomainComponent } from './domain/domain.component';
import { ProfileComponent } from './profile/profile.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BranchService }  from './service/branch.service';
import { DepartmentService } from './service/department.service';
import { CategoryService } from './service/category.service';

@NgModule({
  declarations: [
    AppComponent,
    DomainComponent,
    ProfileComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [BranchService,CategoryService,DepartmentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
